export default [
  {
    title: 'Ice cream is made with carrageenan …',
    image: 'https://images.unsplash.com/photo-1516559828984-fb3b99548b21?ixlib=rb-1.2.1&auto=format&fit=crop&w=2100&q=80',
    text: 'View article', 
    horizontal: true
  },
  {
    title: '',
    image: 'https://imagesvc.meredithcorp.io/v3/mm/image?q=85&c=sc&poi=face&w=1800&h=900&url=https:%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F13%2F2020%2F09%2F25%2Fwhere-to-donate-clothes-social.jpg',
    cta: 'Donors',
    page:"Drivers",

  },
  {
    title: '',
    image: 'https://www.kaaf.bh/assets/images/normalProjects/medium/7862c13fef7ead5f069fa242d98482d4.jpg',
    cta: 'Families' ,
    page:"Drivers",

  },
  {
    title: '',
    image: 'https://res.cloudinary.com/hnpb47ejt/image/upload/v1523401137/fqcwhgizfa3pvkpxcu8a.jpg',
    cta: 'Inventory workers' ,
    page:"InventoryClerks",

  },
  {
    title: '',
    image: 'https://www.uneecops.com/wp-content/uploads/2018/08/dashboard-hrone-banner.jpg',
    cta: '', 
    page:"Drivers",

    horizontal: true
  },
];
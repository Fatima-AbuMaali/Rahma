export default tabs = {
  categories: [
    { id: 'popular', title: 'Popular' },
    { id: 'beauty', title: 'Beauty' },
    { id: 'fashion', title: 'Fashion' },
    { id: 'car_motorcycle', title: 'Car & Motorcycle' },
  ],
}